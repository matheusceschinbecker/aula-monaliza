let poop = 'brown' // variavel
let bulicax 
let bulicay 

function setup() {
  createCanvas(400, 400);// espaço para plano de desenho
}

function draw() {
  let bulicax =map(mouseX,0,400,92,148)//delimitaçao da pupila horizontal
  let bulicay =map(mouseY,0,400,123,181)//delimitação da pupila vertical
  
  background(220);// cor do plano de fundo
  fill(poop) // cor subsequente
  circle(200,200,300)//cabeça
  fill('rgb(26,224,26)')
  circle(120,151,60)
  circle(263,151,60)
  fill('red')
  circle(bulicax,bulicay,15)
  circle(bulicax+135,bulicay,15)
  
  line(29,105,357,90)
  triangle(31,105,71,29,110,100)
  triangle(292,92,358,91,308,38)
  fill('white')
  quad(109,99,105,36,285,29,291,92)
 textSize(20)
  fill('red')
  text("豆腐を食べる人",126,75,)
  fill('#6F0381')
  triangle(188,185,150,231,203,222)
    rect(124,293,136,200,150,150,150,150)
  fill('black')
  triangle(153,277,226,278,184,340)
  fill('pink')
  rect(170,278, 35, 30, 20, 15, 10, 5)

  if(mouseIsPressed){ //condição para ver cordenadas
    console.log(mouseX,mouseY)
  }
}